<!DOCTYPE html>
 <!-- <?php 
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "v2v_couriers";
// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}
$sql = "SELECT * FROM users";
$result = $conn->query($sql);

echo "Connected successfully";

while($row = $result->fetch_assoc()) {
        print_r($row);
    }
 ?> -->
<html lang="en">

<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>V2V Couriers</title>
    <!--  bootstrap css -->
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.6/css/bootstrap.min.css" integrity="sha384-1q8mTJOASx8j1Au+a5WDVnPi2lkFfwwEAa8hDDdjZlpLegxhjVME1fgjWPGmkzs7" crossorigin="anonymous">
    <!--  font Awesome Css  -->
    <link href="http://maxcdn.bootstrapcdn.com/font-awesome/4.5.0/css/font-awesome.min.css" rel="stylesheet">
    <!--    stylesheet for fonts-->
    <link href="fonts/stylesheet.css" rel="stylesheet">
    <!-- Reset css-->
    <link href="css/reset.css" rel="stylesheet">

    <!--slick css-->
    <link href="css/slick.css" rel="stylesheet">
    <!--  owl-carousel css -->
    <link href="css/owl.carousel.css" rel="stylesheet">
    <!--  YTPlayer css For Background Video -->
    <link href="css/jquery.mb.YTPlayer.min.css" rel="stylesheet">
    <link rel="stylesheet" href="css/meanmenu.css">
    <!--  style css  -->
    <link href="style.css" rel="stylesheet">
    <!--  Responsive Css  -->
    <link href="css/responsive.css" rel="stylesheet">

<link href="css/trackstyle.css" rel="stylesheet" type="text/css" media="all" />

    <!--  browser campatibel css files-->
    <!--[if lt IE 9]>
        <script src="//oss.maxcdn.com/html5shiv/3.7.2/html5shiv.min.js"></script>
        <script src="//oss.maxcdn.com/respond/1.4.2/respond.min.js"></script>
    <![endif]-->
</head>

<body class="js">
<?php 
if(isset($_POST['tracking_id'])){
	$tracking_id = $_POST['tracking_id'];
}else{
	$tracking_id = "N/A";
}
?>
    <div id="preloader"></div>
    <!--start header area-->
    <section class="third four header_area" id="home">
        <div class="logo_menu" id="sticker">
            <div class="container">
                <div class="row">
                    <div class="col-md-2 col-lg-2 col-sm-2 col-xs-6">
                        <div class="logo">
                            <a href="#"><img src="img/logo.png" alt="logo"></a>
                        </div>
                    </div>
                    <div class="col-md-6 col-xs-6 col-md-offset-1 col-sm-7 col-lg-offset-1 col-lg-6 mobMenuCol">
                        <nav class="navbar">
                            <ul class="nav navbar-nav navbar-right menu">
								<li><a href="index.html">Home</a></li>
                            </ul> 
                        </nav>
                    </div>
                    <div class="col-md-3 col-sm-3 col-xs-4 col-lg-3 signup">
                        <ul class="nav navbar-nav">
                            <li><a href="login.html">sign in</a></li>
                            <li><a href="register.html">sign up</a></li>
                        </ul>
                    </div>
                </div>
            </div>
        </div>
        <!-- ============= hero_area start ============== -->
        <div class="hero_area" style="background-color:#666666">
		
<div class="header">
	<h1>Shipment Track</h1>
</div>

<div class="content">
	<div class="content1">
		<h2>Order Tracking ID:  <?php echo $tracking_id;?></h2>
	</div>
	<div class="content2">
		<div class="content2-header1">
			<p>Shipped Via : <span>V2V Couriers</span></p>
		</div>
		<div class="content2-header1">
			<p>Status : <span>Checking Quality</span></p>
		</div>
		<div class="content2-header1">
			<p>Expected Date : <span>7-JULY-2020</span></p>
		</div>
		<div class="clear"></div>
	</div>
	<div class="content3">
        <div class="shipment">
			<div class="confirm">
                <div class="imgcircle">
                    <img src="img/confirm1.png" alt="confirm order">
            	</div>
				<span class="line"></span>
				<p>Confirmed Order</p>
			</div>
			<div class="process">
           	 	<div class="imgcircle">
                	<img src="img/process1.png" alt="process order">
            	</div>
				<span class="line"></span>
				<p>Processing Order</p>
			</div>
			<div class="quality">
				<div class="imgcircle">
                	<img src="img/quality1.png" alt="quality check">
            	</div>
				<span class="line"></span>
				<p>Quality Check</p>
			</div>
			<div class="dispatch">
				<div class="imgcircle">
                	<img src="img/delivery1.png" alt="dispatch product">
            	</div>
				<span class="line"></span>
				<p>Dispatched Item</p>
			</div>
			<div class="delivery">
				<div class="imgcircle">
                	<img src="img/person.png" alt="delivery">
				</div>
				<p>Product Delivered</p>
			</div>
			<div class="clear"></div>
		</div>
	</div>
</div>
        </div>
        <!-- ============= hero_area end ============== -->

    </section>
    <!--end of header area-->
    <!--start footer area-->
    <section class="footer-area" id="contact">
        <div class="container">
            <div class="row">
                <div class="col-md-4 col-sm-3 col-xs-12 col-lg-4">
                    <div class="single-footer">
                        <h2>about us</h2>
                        <p>Our vision is to provide on time delivery,monitor and track your products.We give door to door delivery,easy payment options.And also you can track your products.</p>
                    </div>
                </div>
                <div class="col-md-2 col-sm-3 col-xs-12 col-lg-2">
                    <div class="single-footer" id="contact">
                        <h2>ADDRESS:</h2>
                        <ul class="list">
                            <li><a href="#">12, Anna Salai,</a></li>
                            <li><a href="#">Muruga Nagar,</a></li>
                            <li><a href="#">Coimbatore.</a></li>
                            <li><a href="#">Email:swsav2v@gmail.com</a></li>
                            <li><a href="#">Phone:+91 87766 55443</a></li>
                        </ul>
                    </div>
                </div>
                <div class="col-md-3 col-sm-3 col-xs-12 col-lg-3">
                    <div class="single-footer">
                        <h2>We Accepts</h2>
                        <a href="#"><img src="img/7.jpg" alt="#"></a>
                    </div>
                </div>
                <div class="col-md-3 col-sm-3 col-xs-12 col-lg-3">
                    <div class="single-footer clearfix">
                        <h2>news letters</h2>
                        <input type="text" placeholder="Enter your email" class="form-control">
                        <input type="submit" class="submt-button" value="submit">
                    </div>
                </div>
            </div>
        </div>
    </section>
    <!--end of fotter area-->
    <!--   start copyright text area-->
    <div class="copyright-area">
        <div class="container">
            <div class="col-xs-12 col-sm-6 col-md-6 text-left">
                <div class="footer-text">
                    <p>@Copyright <b>V2V Couriers</b> , All Rights Reserved</p>
                </div>
            </div>
            <div class="col-xs-12  col-sm-6 col-md-6 text-right">
                <div class="footer-text">
                    <a href="#" class="fa fa-facebook"></a>
                    <a href="#" class="fa fa-twitter"></a>
                    <a href="#" class="fa fa-linkedin"></a>
                    <a href="#" class="fa fa-google-plus"></a>
                    <a href="#" class="fa fa-dribbble"></a>
                </div>
            </div>
        </div>
    </div>

    <!--    end of copyright text area-->

    <!--  jquery.min.js  -->
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/1.12.2/jquery.min.js"></script>
    <!--    bootstrap.min.js-->
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.6/js/bootstrap.min.js" integrity="sha384-0mSbJDEHialfmuBBQP6A4Qrprq5OVfW37PRR3j5ELqxss1yVqOtnepnHVP9aJ7xS" crossorigin="anonymous"></script>
    <!--    jquery.sticky.js-->
    <script src="js/jquery.sticky.js"></script>
    <!--  owl.carousel.min.js  -->
    <script src="js/owl.carousel.min.js"></script>
    <!--  jquery.mb.YTPlayer.min.js   -->
    <script src="js/jquery.mb.YTPlayer.min.js"></script>
    <!--    slick.min.js-->
    <script src="js/slick.min.js"></script>
    <script src="js/jquery.meanmenu.js"></script>
    <!--    jquery.nav.js-->
    <script src="js/jquery.nav.js"></script>
    <!--jquery waypoints js-->
    <script src="http://cdnjs.cloudflare.com/ajax/libs/waypoints/2.0.3/waypoints.min.js"></script>
    <!--    jquery counterup js-->
    <script src="js/jquery.counterup.min.js"></script>
    <!--    main.js-->
    <script src="js/main.js"></script>
</body>

</html>